// Pienter-stijl archive screen — toont system met nieuwe palette in context.

const PienterArchive = () => {
  const people = [
    { naam: 'Niek Visser',    rol: 'UX Webdesign',     tag: 'Team website' },
    { naam: 'Sanne Krijger',  rol: 'Account manager',  tag: 'Team sales' },
    { naam: 'Jens van Dijk',  rol: 'Frontend dev',     tag: 'Team product' },
    { naam: 'Iris Klamer',    rol: 'Designer',         tag: 'Team website' },
    { naam: 'Daan Versteeg',  rol: 'Backend dev',      tag: 'Team product' },
    { naam: 'Hester Tellier', rol: 'Marketing',        tag: 'Team sales' },
    { naam: 'Pjotr Bakker',   rol: 'Sales',            tag: 'Team sales' },
    { naam: 'Yusuf Aydın',    rol: 'Lead designer',    tag: 'Team product' },
    { naam: 'Ineke Robben',   rol: 'PM',               tag: 'Team product' },
  ];

  // Decoratieve roze blob in fotokader
  const Blob = ({ style = {} }) => (
    <svg viewBox="0 0 120 64" preserveAspectRatio="none" style={{ position: 'absolute', right: 0, bottom: 0, width: '55%', height: '100%', ...style }}>
      <path d="M-10 64 C 20 30, 40 50, 60 36 C 80 22, 100 44, 130 30 L 130 64 Z" fill="var(--accent)" opacity=".55" />
      <path d="M20 64 C 50 44, 60 56, 90 44 C 110 36, 120 50, 140 44 L 140 64 Z" fill="var(--accent)" opacity=".85" />
    </svg>
  );

  const Card = ({ p }) => {
    const initial = p.naam.split(' ').map(s => s[0]).join('');
    return (
      <div style={{
        position: 'relative',
        background: 'var(--surface)',
        border: '1px solid var(--line)',
        borderRadius: 'var(--r-3)',
        overflow: 'hidden',
        boxShadow: 'var(--shadow-1)',
        display: 'grid',
        gridTemplateColumns: '64px 1fr auto',
        gap: 14,
        padding: 12,
        alignItems: 'center',
        transition: 'box-shadow .15s, transform .15s',
      }}>
        {/* Foto / avatar */}
        <div style={{
          width: 64, height: 64, borderRadius: '50%',
          background: 'var(--accent)', flexShrink: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--on-accent)', fontWeight: 600, fontSize: 18,
          letterSpacing: '-0.02em', zIndex: 1, position: 'relative',
        }}>{initial}</div>

        {/* Naam + rol */}
        <div style={{ minWidth: 0, zIndex: 1 }}>
          <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--ink)' }}>{p.naam}</div>
          <div style={{ fontSize: 12, color: 'var(--ink-3)' }}>{p.rol}</div>
        </div>

        {/* Tag */}
        <span className="badge badge-highlight" style={{ zIndex: 1, alignSelf: 'flex-start' }}>{p.tag}</span>

        {/* Decoratieve roze blob */}
        <Blob />
      </div>
    );
  };

  return (
    <div className="veld-frame" style={{ background: 'var(--bg)' }}>
      <main style={{ padding: 0, display: 'grid', gridTemplateColumns: '232px 1fr', height: '100%' }}>
        {/* Sidebar */}
        <aside style={{ background: 'var(--surface)', borderRight: '1px solid var(--line)', padding: '24px 18px', display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div style={{ fontWeight: 700, fontSize: 15, letterSpacing: '-0.01em', marginBottom: 24 }}>Pienter Dashboard</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 8px', borderBottom: '1px solid var(--line)', fontWeight: 500, fontSize: 14, color: 'var(--ink)' }}>
            <VeldIcon name="user" size={16} strokeWidth={1.6} />Klanten
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 8px', borderBottom: '1px solid var(--line)', fontWeight: 600, fontSize: 14, color: 'var(--ink)' }}>
            <VeldIcon name="user" size={16} strokeWidth={1.6} />Medewerkers
            <VeldIcon name="chevD" size={14} style={{ marginLeft: 'auto', transform: 'rotate(180deg)' }} />
          </div>

          <div style={{ marginTop: 'auto', padding: 10, background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 'var(--r-3)', boxShadow: 'var(--shadow-1)' }}>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <span className="avatar" style={{ background: 'var(--bg-elev)', color: 'var(--ink-2)' }}>NV</span>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 12.5, fontWeight: 600 }}>Niek Visser</div>
                <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>UX Webdesign</div>
              </div>
            </div>
          </div>
        </aside>

        {/* Workspace */}
        <section style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <header style={{ height: 42, padding: '0 28px', display: 'flex', alignItems: 'center', fontSize: 12.5, color: 'var(--ink-2)', borderBottom: '1px solid var(--line)' }}>
            Medewerkers
          </header>
          <div style={{ flex: 1, padding: '24px 28px', overflow: 'hidden' }}>
            <h1 style={{ fontSize: 36, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--primary)', margin: '0 0 18px' }}>
              Archive<Pip color="var(--accent)" size={10} style={{ marginLeft: 4 }} />
            </h1>

            <div className="card" style={{ padding: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 6, marginBottom: 14 }}>
                <button className="btn btn-ghost btn-sm" style={{ width: 28, padding: 0, height: 28 }}><VeldIcon name="pipeline" size={14} /></button>
                <button className="btn btn-ghost btn-sm" style={{ width: 28, padding: 0, height: 28, background: 'var(--bg-elev)' }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                </button>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
                {people.map((p, i) => <Card key={i} p={p} />)}
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

Object.assign(window, { PienterArchive });
