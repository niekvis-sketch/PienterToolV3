// Veld Design System — App shell + Tweaks
// Wires every artboard into the design canvas; Tweaks control CSS variables
// on the .veld wrapper (theme, accent, density, radius).

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "cream",
  "accent": "rose",
  "density": "comfortable",
  "radius": "subtle"
}/*EDITMODE-END*/;

function VeldApp() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Map "rose" accent to the default token set; others map via data-accent.
  const accentAttr = t.accent === 'rose' ? null : t.accent;

  return (
    <div
      className="veld"
      data-theme={t.theme}
      data-accent={accentAttr || undefined}
      data-density={t.density}
      data-radius={t.radius}
      style={{ position: 'absolute', inset: 0 }}
    >
      <DesignCanvas>
        <DCSection id="intro" title="Intro" subtitle="Cover van het systeem">
          <DCArtboard id="cover" label="Intro" width={920} height={680}><FoundationsIntro /></DCArtboard>
        </DCSection>

        <DCSection id="found" title="Foundations" subtitle="De bouwstenen van Veld">
          <DCArtboard id="brand"     label="Brand"          width={760}  height={680}><FoundationsBrand /></DCArtboard>
          <DCArtboard id="colors"    label="Kleurpalet"      width={920}  height={680}><FoundationsColors /></DCArtboard>
          <DCArtboard id="type"      label="Typografie"      width={820}  height={680}><FoundationsType /></DCArtboard>
          <DCArtboard id="radii"     label="Radii & spacing" width={820}  height={680}><FoundationsRadiiShadows /></DCArtboard>
          <DCArtboard id="icons"     label="Iconografie"     width={760}  height={680}><FoundationsIcons /></DCArtboard>
        </DCSection>

        <DCSection id="comp" title="Components" subtitle="Buttons, forms, badges">
          <DCArtboard id="buttons"   label="Buttons"   width={760} height={680}><ComponentsButtons /></DCArtboard>
          <DCArtboard id="forms"     label="Forms"     width={920} height={680}><ComponentsForms /></DCArtboard>
          <DCArtboard id="badges"    label="Badges & tags" width={760} height={680}><ComponentsBadges /></DCArtboard>
        </DCSection>

        <DCSection id="patt" title="Patterns" subtitle="Composieten — navigatie, cards, tabel, charts">
          <DCArtboard id="nav"       label="Navigatie"  width={1080} height={680}><PatternsNavigation /></DCArtboard>
          <DCArtboard id="cards"     label="Cards"      width={820}  height={680}><PatternsCards /></DCArtboard>
          <DCArtboard id="table"     label="Tabel"      width={980}  height={680}><PatternsTable /></DCArtboard>
          <DCArtboard id="charts"    label="Charts"     width={820}  height={680}><PatternsCharts /></DCArtboard>
        </DCSection>

        <DCSection id="screen" title="In context" subtitle="Het system in een CRM dashboard">
          <DCArtboard id="dash"      label="CRM dashboard" width={1280} height={820}><ScreenDashboard /></DCArtboard>
          <DCArtboard id="archive"   label="Pienter — Archive" width={1280} height={820}><PienterArchive /></DCArtboard>
        </DCSection>

        <DCPostIt top={40} left={40} rotate={-3} width={200}>
          Veld = warm, rustig, helder. Roze speelt een bijrol: kleine accenten waar nieuwheid of aandacht telt.
        </DCPostIt>
      </DesignCanvas>

      <TweaksPanel title="Tweaks · Veld">
        <TweakSection label="Thema" />
        <TweakRadio
          label="Achtergrond"
          value={t.theme}
          options={[
            { value: 'cream', label: 'Crème' },
            { value: 'cool', label: 'Koel' },
            { value: 'dark', label: 'Donker' },
          ]}
          onChange={(v) => setTweak('theme', v)}
        />
        <TweakColor
          label="Accent"
          value={t.accent}
          options={[
            { value: 'rose',  swatch: '#F6BDCA' },
            { value: 'amber', swatch: '#FFAB40' },
            { value: 'coral', swatch: '#F1A48E' },
            { value: 'lilac', swatch: '#C9B6E8' },
          ]}
          onChange={(v) => setTweak('accent', v)}
        />
        <TweakSection label="Layout" />
        <TweakRadio
          label="Density"
          value={t.density}
          options={[
            { value: 'compact', label: 'Compact' },
            { value: 'comfortable', label: 'Comfort' },
            { value: 'spacious', label: 'Ruim' },
          ]}
          onChange={(v) => setTweak('density', v)}
        />
        <TweakRadio
          label="Radius"
          value={t.radius}
          options={[
            { value: 'sharp',  label: 'Scherp' },
            { value: 'subtle', label: 'Subtiel' },
            { value: 'soft',   label: 'Zacht' },
          ]}
          onChange={(v) => setTweak('radius', v)}
        />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<VeldApp />);
