// Patterns — Navigation / Cards / Tables / Charts

const PatternsNavigation = () => (
  <div className="veld-frame">
    <main style={{ padding: 0 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '232px 1fr', height: '100%' }}>
        {/* Sidebar */}
        <aside style={{ background: 'var(--bg-elev)', borderRight: '1px solid var(--line)', padding: '20px 14px', display:'flex', flexDirection:'column', gap: 20 }}>
          <div style={{ display:'flex', alignItems:'center', gap: 10, padding: '4px 6px' }}>
            <div style={{ width: 28, height: 28, borderRadius: 'var(--r-2)', background: 'var(--primary)', display:'flex', alignItems:'center', justifyContent:'center', color: 'var(--on-primary)', fontWeight: 700, fontSize: 14 }}>V</div>
            <span style={{ fontWeight: 600, letterSpacing: '-0.01em' }}>Veld CRM</span>
            <Pip />
          </div>
          <div>
            <div className="caps" style={{ padding: '0 8px 8px' }}>Werkruimte</div>
            <div style={{ display:'flex', flexDirection:'column', gap: 2 }}>
              <div className="nav-item is-active"><VeldIcon name="home" size={17} />Overzicht</div>
              <div className="nav-item"><VeldIcon name="contacts" size={17} />Klanten<span style={{ marginLeft:'auto', fontSize: 11, color: 'var(--ink-3)' }} className="mono">248</span></div>
              <div className="nav-item"><VeldIcon name="deals" size={17} />Deals<span className="badge badge-accent" style={{ marginLeft:'auto', height: 18, padding:'0 7px', fontSize: 10.5 }}>3</span></div>
              <div className="nav-item"><VeldIcon name="pipeline" size={17} />Pijplijn</div>
              <div className="nav-item"><VeldIcon name="inbox" size={17} />Inbox</div>
              <div className="nav-item"><VeldIcon name="calendar" size={17} />Agenda</div>
            </div>
          </div>
          <div>
            <div className="caps" style={{ padding: '0 8px 8px' }}>Inzicht</div>
            <div style={{ display:'flex', flexDirection:'column', gap: 2 }}>
              <div className="nav-item"><VeldIcon name="chart" size={17} />Rapportages</div>
              <div className="nav-item"><VeldIcon name="settings" size={17} />Instellingen</div>
            </div>
          </div>
          <div style={{ marginTop:'auto', padding: 12, background:'var(--surface)', border:'1px solid var(--line)', borderRadius:'var(--r-3)' }}>
            <div style={{ display:'flex', gap: 10, alignItems:'center' }}>
              <span className="avatar">SK</span>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 500, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>Sanne Krijger</div>
                <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>Account manager</div>
              </div>
            </div>
          </div>
        </aside>

        {/* Workspace */}
        <section style={{ display:'flex', flexDirection:'column' }}>
          <header style={{ height: 60, borderBottom: '1px solid var(--line)', display:'flex', alignItems:'center', padding:'0 24px', gap: 16, background: 'var(--bg)' }}>
            <div style={{ display:'flex', alignItems:'center', gap: 8, fontSize: 13, color: 'var(--ink-3)' }}>
              <span>Werkruimte</span><VeldIcon name="chevR" size={13} /><span style={{ color: 'var(--ink)', fontWeight: 500 }}>Overzicht</span>
            </div>
            <div style={{ marginLeft: 'auto', display:'flex', gap: 10, alignItems:'center' }}>
              <div style={{ position:'relative' }}>
                <VeldIcon name="search" size={15} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'var(--ink-3)' }} />
                <input className="input" placeholder="Zoek…" style={{ width: 220, height: 36, paddingLeft: 32 }} />
                <span className="mono" style={{ position:'absolute', right: 8, top: '50%', transform:'translateY(-50%)', fontSize: 10.5, color: 'var(--ink-3)', background: 'var(--bg)', padding: '2px 6px', borderRadius: 4, border: '1px solid var(--line)' }}>⌘K</span>
              </div>
              <button className="btn btn-secondary" style={{ width: 36, padding: 0, height: 36 }}>
                <span style={{ position:'relative' }}><VeldIcon name="bell" size={16} /><Pip size={6} style={{ position:'absolute', top: -2, right: -2 }} /></span>
              </button>
              <button className="btn btn-primary btn-sm"><VeldIcon name="plus" size={14} />Nieuw</button>
            </div>
          </header>
          <div style={{ flex: 1, padding: 24 }}>
            <div style={{ display:'flex', gap: 6, marginBottom: 18 }}>
              {['Overzicht','Activiteit','Doelen','Notities'].map((t,i) => (
                <div key={t} style={{
                  padding: '8px 14px', fontSize: 13, fontWeight: 500,
                  color: i === 0 ? 'var(--ink)' : 'var(--ink-3)',
                  borderBottom: i === 0 ? '2px solid var(--primary)' : '2px solid transparent',
                  cursor: 'pointer',
                }}>{t}</div>
              ))}
            </div>
            <div style={{ display:'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
              {[
                ['Actieve deals', '24', 'success'],
                ['Pijplijn waarde', '€ 184k', 'primary'],
                ['Nieuwe leads · wk', '12', 'accent'],
              ].map(([k, v, c]) => (
                <div key={k} className="card" style={{ padding: 16 }}>
                  <div className="caps" style={{ marginBottom: 6 }}>{k}</div>
                  <div style={{ fontSize: 26, fontWeight: 600, letterSpacing: '-0.02em', color: c === 'accent' ? 'var(--accent-press)' : 'var(--ink)' }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </main>
  </div>
);

const PatternsCards = () => (
  <div className="veld-frame">
    <main>
      <ABHead eyebrow="Patterns" title="Cards" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, alignContent: 'start' }}>
        <div className="card">
          <div className="card-body" style={{ display:'flex', gap: 14 }}>
            <span className="avatar is-accent" style={{ width: 48, height: 48, fontSize: 16 }}>MV</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display:'flex', alignItems:'center', gap: 8 }}>
                <span style={{ fontWeight: 600 }}>Mira van Dijk</span>
                <Pip color="var(--success)" />
                <span style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>Online</span>
              </div>
              <div style={{ fontSize: 13, color: 'var(--ink-3)' }}>De Korenmaat B.V. · Utrecht</div>
              <div style={{ display:'flex', gap: 8, marginTop: 10 }}>
                <span className="badge badge-accent"><Pip size={5} color="var(--accent-press)" />Hot lead</span>
                <span className="badge badge-neutral">SaaS</span>
              </div>
            </div>
            <button className="btn btn-ghost btn-sm" style={{ width: 32, padding: 0 }}><VeldIcon name="dots" size={16} /></button>
          </div>
        </div>

        <div className="card">
          <div className="card-body">
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
              <div>
                <div className="caps">Maand omzet</div>
                <div style={{ fontSize: 34, fontWeight: 600, letterSpacing: '-0.02em', marginTop: 4 }}>€ 48.210</div>
              </div>
              <span className="badge badge-success"><VeldIcon name="arrowUp" size={11} strokeWidth={2.4} />+ 12%</span>
            </div>
            <svg viewBox="0 0 220 50" style={{ width: '100%', marginTop: 12 }}>
              <path d="M0 38 L20 32 L40 34 L60 28 L80 24 L100 26 L120 20 L140 18 L160 14 L180 16 L200 8 L220 10" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
              <circle cx="200" cy="8" r="3.5" fill="var(--accent)" />
            </svg>
          </div>
        </div>

        <div className="card" style={{ gridColumn: '1 / -1' }}>
          <div className="card-header">
            <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
              <span style={{ fontWeight: 600 }}>Recente activiteit</span>
              <span className="badge badge-neutral">4 nieuw</span>
            </div>
            <button className="btn btn-ghost btn-sm">Alles tonen<VeldIcon name="arrowR" size={13} /></button>
          </div>
          <div style={{ padding: '8px 18px' }}>
            {[
              { who: 'Jens', what: 'heeft een offerte verstuurd aan', whom: 'De Korenmaat', when: '4 min', icon: 'mail', tone: 'primary' },
              { who: 'Iris', what: 'heeft een afspraak gepland met', whom: 'KaalKeurig', when: '1 uur', icon: 'calendar', tone: 'accent' },
              { who: 'Daan', what: 'voegde een notitie toe bij', whom: 'Boombond NL', when: 'gisteren', icon: 'edit', tone: 'neutral' },
            ].map((r, i) => (
              <div key={i} style={{ display:'flex', alignItems:'center', gap: 12, padding: '12px 0', borderBottom: i < 2 ? '1px dashed var(--line)' : 'none' }}>
                <span style={{
                  width: 32, height: 32, borderRadius: 'var(--r-2)',
                  background: r.tone === 'accent' ? 'var(--accent-soft)' : r.tone === 'primary' ? 'var(--primary-soft)' : 'var(--bg-elev)',
                  color: r.tone === 'accent' ? 'var(--accent-press)' : r.tone === 'primary' ? 'var(--primary)' : 'var(--ink-2)',
                  display:'flex', alignItems:'center', justifyContent:'center',
                }}><VeldIcon name={r.icon} size={15} /></span>
                <div style={{ flex: 1, fontSize: 13.5 }}>
                  <strong style={{ fontWeight: 500 }}>{r.who}</strong> <span style={{ color: 'var(--ink-2)' }}>{r.what}</span> <strong style={{ fontWeight: 500 }}>{r.whom}</strong>
                </div>
                <span className="mono" style={{ fontSize: 11, color: 'var(--ink-3)' }}>{r.when}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  </div>
);

const PatternsTable = () => {
  const rows = [
    { naam: 'De Korenmaat B.V.', contact: 'Mira van Dijk', fase: 'Onderhandeling', faseColor: 'warning', waarde: 24500, eigenaar: 'JV', kans: 78 },
    { naam: 'KaalKeurig',         contact: 'Pjotr Bakker',  fase: 'Demo',          faseColor: 'primary', waarde: 8400,  eigenaar: 'IK', kans: 52 },
    { naam: 'Boombond NL',        contact: 'Hester Tellier', fase: 'Offerte',       faseColor: 'accent',  waarde: 18200, eigenaar: 'DV', kans: 64 },
    { naam: 'Lumen Studio',       contact: 'Yusuf Aydın',    fase: 'Gewonnen',      faseColor: 'success', waarde: 42000, eigenaar: 'SK', kans: 100 },
    { naam: 'Vlas & Veen',        contact: 'Ineke Robben',   fase: 'Lead',          faseColor: 'neutral', waarde: 0,     eigenaar: 'JV', kans: 8  },
    { naam: 'Stroom Architecten', contact: 'Lars Bremen',    fase: 'Verloren',      faseColor: 'danger',  waarde: 0,     eigenaar: 'IK', kans: 0  },
  ];
  return (
    <div className="veld-frame">
      <main>
        <ABHead eyebrow="Patterns" title="Tabel" hint="hover · sortable · status" />
        <div className="card" style={{ overflow: 'hidden' }}>
          <div style={{ display:'flex', alignItems:'center', padding: '12px 16px', borderBottom: '1px solid var(--line)', gap: 10 }}>
            <div style={{ position:'relative', flex: '0 0 240px' }}>
              <VeldIcon name="search" size={14} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'var(--ink-3)' }} />
              <input className="input" placeholder="Filter klanten…" style={{ height: 32, fontSize: 13, paddingLeft: 30 }} />
            </div>
            <button className="btn btn-secondary btn-sm"><VeldIcon name="filter" size={13} />Fase</button>
            <button className="btn btn-secondary btn-sm"><VeldIcon name="filter" size={13} />Eigenaar</button>
            <span style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--ink-3)' }}>6 van 248</span>
          </div>
          <table className="tbl">
            <thead>
              <tr>
                <th style={{ width: 30 }}></th>
                <th>Klant <VeldIcon name="sort" size={11} style={{ display:'inline', marginLeft: 4, verticalAlign:'middle' }} /></th>
                <th>Contact</th>
                <th>Fase</th>
                <th style={{ textAlign: 'right' }}>Waarde</th>
                <th>Kans</th>
                <th style={{ width: 60 }}>Eigenaar</th>
                <th style={{ width: 30 }}></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={i}>
                  <td><Checkbox /></td>
                  <td style={{ fontWeight: 500 }}>{r.naam}</td>
                  <td style={{ color: 'var(--ink-2)' }}>{r.contact}</td>
                  <td><span className={`badge badge-${r.faseColor}`}><span className="dot" />{r.fase}</span></td>
                  <td className="mono" style={{ textAlign: 'right', color: r.waarde ? 'var(--ink)' : 'var(--ink-3)' }}>
                    {r.waarde ? `€ ${r.waarde.toLocaleString('nl-NL')}` : '—'}
                  </td>
                  <td style={{ minWidth: 110 }}>
                    <div style={{ display:'flex', alignItems:'center', gap: 8 }}>
                      <div style={{ height: 6, flex: 1, background: 'var(--line)', borderRadius: 3, overflow:'hidden' }}>
                        <div style={{ height: '100%', width: `${r.kans}%`, background: r.kans >= 80 ? 'var(--success)' : r.kans >= 40 ? 'var(--primary)' : r.kans > 0 ? 'var(--accent)' : 'var(--ink-mute)' }} />
                      </div>
                      <span className="mono" style={{ fontSize: 11, color: 'var(--ink-3)', width: 28 }}>{r.kans}%</span>
                    </div>
                  </td>
                  <td><span className="avatar" style={{ width: 26, height: 26, fontSize: 10 }}>{r.eigenaar}</span></td>
                  <td><button className="btn btn-ghost btn-sm" style={{ width: 26, padding: 0, height: 26 }}><VeldIcon name="dots" size={14} /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
};

const PatternsCharts = () => {
  const data = [22, 26, 24, 30, 28, 34, 38, 36, 42, 40, 46, 48];
  const labels = ['J','F','M','A','M','J','J','A','S','O','N','D'];
  const w = 380, h = 160, pad = 24;
  const maxV = 50;
  const xs = i => pad + (i * (w - pad*2)) / (data.length - 1);
  const ys = v => h - pad - (v / maxV) * (h - pad*2);
  const path = data.map((v,i) => `${i?'L':'M'} ${xs(i)} ${ys(v)}`).join(' ');
  const area = `${path} L ${xs(data.length-1)} ${h-pad} L ${xs(0)} ${h-pad} Z`;

  return (
    <div className="veld-frame">
      <main>
        <ABHead eyebrow="Patterns" title="Charts" hint="rust · subtiele kleur" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div className="card">
            <div className="card-header">
              <div>
                <div className="caps">Omzet 2025</div>
                <div style={{ fontSize: 22, fontWeight: 600, marginTop: 4 }}>€ 384.200</div>
              </div>
              <span className="badge badge-success"><VeldIcon name="arrowUp" size={11} strokeWidth={2.4} />+ 18%</span>
            </div>
            <div className="card-body">
              <svg viewBox={`0 0 ${w} ${h}`} style={{ width: '100%' }}>
                {[10,20,30,40,50].map(t => <line key={t} x1={pad} x2={w-pad} y1={ys(t)} y2={ys(t)} stroke="var(--line)" strokeDasharray="2 3" />)}
                <path d={area} fill="var(--primary-soft)" opacity=".7" />
                <path d={path} fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinejoin="round" />
                {data.map((v,i) => <circle key={i} cx={xs(i)} cy={ys(v)} r={i === data.length-1 ? 4 : 0} fill="var(--accent)" />)}
                {labels.map((l,i) => <text key={i} x={xs(i)} y={h-6} fill="var(--ink-3)" fontSize="9" textAnchor="middle" fontFamily="JetBrains Mono">{l}</text>)}
              </svg>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <div className="caps">Deals per fase</div>
              <span className="mono" style={{ fontSize: 11, color: 'var(--ink-3)' }}>n=64</span>
            </div>
            <div className="card-body">
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  ['Lead', 22, 'var(--ink-mute)'],
                  ['Demo', 14, 'var(--primary-soft-2)'],
                  ['Offerte', 12, 'var(--primary)'],
                  ['Onderhandeling', 8, 'var(--accent)'],
                  ['Gewonnen', 8, 'var(--success)'],
                ].map(([l, v, c]) => (
                  <div key={l} style={{ display:'flex', alignItems:'center', gap: 10, fontSize: 12.5 }}>
                    <span style={{ width: 100, color: 'var(--ink-2)' }}>{l}</span>
                    <div style={{ flex: 1, height: 14, background: 'var(--bg-elev)', borderRadius: 3, overflow:'hidden' }}>
                      <div style={{ width: `${(v/22)*100}%`, height: '100%', background: c, borderRadius: 3 }} />
                    </div>
                    <span className="mono" style={{ width: 22, textAlign: 'right', color: 'var(--ink-3)' }}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="card" style={{ gridColumn: '1 / -1' }}>
            <div className="card-header">
              <div className="caps">Verdeling leadbron</div>
              <button className="btn btn-ghost btn-sm">Deze maand<VeldIcon name="chevD" size={13} /></button>
            </div>
            <div className="card-body" style={{ display:'grid', gridTemplateColumns: '180px 1fr', gap: 24, alignItems:'center' }}>
              <svg viewBox="0 0 100 100" style={{ width: 160, height: 160 }}>
                {(() => {
                  const segs = [
                    { v: 42, c: 'var(--primary)' },
                    { v: 28, c: 'var(--accent)' },
                    { v: 18, c: 'var(--primary-soft-2)' },
                    { v: 12, c: 'var(--warning)' },
                  ];
                  let a = -90;
                  return segs.map((s, i) => {
                    const len = (s.v / 100) * 360;
                    const r = 38, c = 2 * Math.PI * r;
                    const dash = (len / 360) * c;
                    const off = ((a + 90) / 360) * c;
                    a += len;
                    return <circle key={i} cx="50" cy="50" r={r} fill="none" stroke={s.c} strokeWidth="14" strokeDasharray={`${dash} ${c}`} strokeDashoffset={-off} transform="rotate(-90 50 50)" />;
                  });
                })()}
                <text x="50" y="48" textAnchor="middle" fontSize="14" fontWeight="600" fill="var(--ink)">64</text>
                <text x="50" y="60" textAnchor="middle" fontSize="6" fill="var(--ink-3)" fontFamily="JetBrains Mono">leads</text>
              </svg>
              <div style={{ display:'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 13 }}>
                {[
                  ['Website', 42, 'var(--primary)'],
                  ['Aanbeveling', 28, 'var(--accent)'],
                  ['LinkedIn', 18, 'var(--primary-soft-2)'],
                  ['Events', 12, 'var(--warning)'],
                ].map(([l, v, c]) => (
                  <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <Pip color={c} />
                    <span style={{ color: 'var(--ink-2)', flex: 1 }}>{l}</span>
                    <span className="mono" style={{ color: 'var(--ink-3)' }}>{v}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

Object.assign(window, { PatternsNavigation, PatternsCards, PatternsTable, PatternsCharts });
