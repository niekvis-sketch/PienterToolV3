// Components — Buttons / Forms / Badges

const ComponentsButtons = () => {
  const Group = ({ label, children }) => (
    <div>
      <div className="caps" style={{ marginBottom: 12 }}>{label}</div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>{children}</div>
    </div>
  );
  // State sub-row: 3 buttons in default / hover / disabled
  const StateRow = ({ render }) => (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, max-content)', columnGap: 14, rowGap: 6, alignItems: 'end' }}>
      <div>{render('default')}</div>
      <div>{render('hover')}</div>
      <div>{render('disabled')}</div>
      <span className="mono" style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>Default</span>
      <span className="mono" style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>Hover</span>
      <span className="mono" style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>Disabled</span>
    </div>
  );
  // Apply state styling to a primary button
  const stateStyle = (s) => {
    if (s === 'hover')    return { background: 'var(--primary-hover)' };
    if (s === 'disabled') return { opacity: .45, cursor: 'not-allowed' };
    return {};
  };
  const stateStyleSecondary = (s) => {
    if (s === 'hover')    return { background: 'var(--surface-2)', borderColor: 'var(--ink-2)' };
    if (s === 'disabled') return { opacity: .45, cursor: 'not-allowed' };
    return {};
  };
  return (
    <div className="veld-frame">
      <main>
        <ABHead eyebrow="Components" title="Buttons" />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>

          <Group label="Variants">
            <button className="btn btn-primary">Nieuwe deal</button>
            <button className="btn btn-destructive"><VeldIcon name="trash" size={15} />Verwijder</button>
            <button className="btn btn-accent"><VeldIcon name="sparkle" size={15} />Vraag Veld AI</button>
            <button className="btn btn-highlight">Team website</button>
            <button className="btn btn-secondary">Importeer</button>
            <button className="btn btn-ghost">Annuleren</button>
          </Group>

          <div>
            <div className="caps" style={{ marginBottom: 12 }}>Met icon</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
              <StateRow render={(s) => (
                <button className="btn btn-primary" style={stateStyle(s)} disabled={s === 'disabled'}>
                  <VeldIcon name="plus" size={15} />Contact toevoegen
                </button>
              )} />
              <StateRow render={(s) => (
                <button className="btn btn-secondary" style={stateStyleSecondary(s)} disabled={s === 'disabled'}>
                  <VeldIcon name="upload" size={15} />Exporteren
                </button>
              )} />
              <StateRow render={(s) => (
                <button className="btn btn-secondary" style={stateStyleSecondary(s)} disabled={s === 'disabled'}>
                  Volgende<VeldIcon name="arrowR" size={15} />
                </button>
              )} />
            </div>
          </div>

          <div>
            <div className="caps" style={{ marginBottom: 12 }}>Icon los</div>
            <StateRow render={(s) => (
              <button
                className="btn btn-secondary"
                style={{ width: 'var(--density-row)', padding: 0, ...stateStyleSecondary(s) }}
                disabled={s === 'disabled'}
              >
                <VeldIcon name="search" size={16} />
              </button>
            )} />
          </div>

        </div>
      </main>
    </div>
  );
};

const ComponentsForms = () => (
  <div className="veld-frame">
    <main>
      <ABHead eyebrow="Components" title="Forms & inputs" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <div>
            <label className="label">Bedrijfsnaam</label>
            <input className="input" defaultValue="De Korenmaat B.V." />
          </div>
          <div>
            <label className="label">E-mailadres</label>
            <input className="input" type="email" placeholder="naam@bedrijf.nl" />
            <div className="help">We sturen geen marketingmails.</div>
          </div>
          <div>
            <label className="label">Pijplijn fase</label>
            <div style={{ position: 'relative' }}>
              <select className="select" style={{ appearance: 'none', paddingRight: 36 }}>
                <option>Eerste contact</option>
                <option>Onderhandeling</option>
                <option>Offerte verstuurd</option>
                <option>Gewonnen</option>
              </select>
              <VeldIcon name="chevD" size={16} style={{ position:'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-3)', pointerEvents:'none' }} />
            </div>
          </div>
          <div>
            <label className="label">Met zoek-icoon</label>
            <div style={{ position: 'relative' }}>
              <VeldIcon name="search" size={16} style={{ position:'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--ink-3)' }} />
              <input className="input" placeholder="Zoek klanten, deals, mails…" style={{ paddingLeft: 38 }} />
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <div>
            <label className="label">Notities</label>
            <textarea className="textarea" defaultValue="Gesproken met Sanne, wil graag een demo plannen in week 23."></textarea>
          </div>
          <div>
            <label className="label">Eigenaar</label>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {['Iris', 'Jens', 'Sanne', 'Daan'].map((n, i) => (
                <button key={n} className="btn btn-secondary btn-sm" style={i === 1 ? { borderColor: 'var(--primary)', color: 'var(--primary)', background: 'var(--primary-soft)' } : {}}>
                  <span className="avatar" style={{ width: 18, height: 18, fontSize: 9 }}>{n[0]}</span>
                  {n}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="label">Voorkeuren</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <Checkbox label="Stuur me een herinnering" defaultChecked />
              <Checkbox label="Voeg toe aan campagne" />
              <Toggle label="Synchroniseer met agenda" defaultChecked />
            </div>
          </div>
          <div>
            <label className="label">Veld met fout</label>
            <input className="input" defaultValue="info@" style={{ borderColor: 'var(--danger)' }} />
            <div className="help" style={{ color: 'var(--danger)' }}>Ongeldig e-mailadres.</div>
          </div>
        </div>
      </div>
    </main>
  </div>
);

const Checkbox = ({ label, defaultChecked }) => {
  const [on, set] = React.useState(!!defaultChecked);
  return (
    <label style={{ display:'flex', alignItems:'center', gap: 10, cursor: 'pointer', fontSize: 13.5, color: 'var(--ink)' }}>
      <span onClick={() => set(!on)} style={{
        width: 18, height: 18, borderRadius: 'var(--r-1)',
        border: `1.5px solid ${on ? 'var(--primary)' : 'var(--line-strong)'}`,
        background: on ? 'var(--primary)' : 'var(--surface)',
        display:'flex', alignItems:'center', justifyContent:'center',
        transition: 'all .15s', color: 'var(--on-primary)',
      }}>
        {on && <VeldIcon name="check" size={12} strokeWidth={2.4} />}
      </span>
      <span>{label}</span>
    </label>
  );
};

const Toggle = ({ label, defaultChecked }) => {
  const [on, set] = React.useState(!!defaultChecked);
  return (
    <label style={{ display:'flex', alignItems:'center', gap: 10, cursor: 'pointer', fontSize: 13.5 }}>
      <span onClick={() => set(!on)} style={{
        width: 34, height: 20, borderRadius: 999,
        background: on ? 'var(--primary)' : 'var(--line-strong)',
        position: 'relative', transition: 'background .15s',
      }}>
        <span style={{
          position:'absolute', top: 2, left: on ? 16 : 2,
          width: 16, height: 16, background: '#fff', borderRadius: '50%',
          transition: 'left .18s cubic-bezier(.2,.7,.3,1)',
          boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
        }} />
      </span>
      <span>{label}</span>
    </label>
  );
};

const ComponentsBadges = () => (
  <div className="veld-frame">
    <main>
      <ABHead eyebrow="Components" title="Badges & tags" />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
        <section>
          <div className="caps" style={{ marginBottom: 12 }}>Status</div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            <span className="badge badge-primary"><span className="dot" />Actief</span>
            <span className="badge badge-accent"><span className="dot" />Nieuw</span>
            <span className="badge badge-highlight"><span className="dot" />Team website</span>
            <span className="badge badge-highlight-soft"><span className="dot" />Featured</span>
            <span className="badge badge-success"><span className="dot" />Gewonnen</span>
            <span className="badge badge-warning"><span className="dot" />Wacht op klant</span>
            <span className="badge badge-danger"><span className="dot" />Verloren</span>
            <span className="badge badge-neutral"><span className="dot" />Concept</span>
          </div>
        </section>
        <section>
          <div className="caps" style={{ marginBottom: 12 }}>Pipeline-fases</div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'stretch', flexWrap:'wrap' }}>
            {['Lead', 'Contact', 'Demo', 'Offerte', 'Onderhandeling', 'Gewonnen'].map((s, i, a) => {
              const active = i <= 3;
              return (
                <div key={s} style={{
                  padding: '8px 14px 8px 18px', fontSize: 12.5, fontWeight: 500,
                  background: active ? 'var(--primary)' : 'var(--surface)',
                  color: active ? 'var(--on-primary)' : 'var(--ink-3)',
                  border: '1px solid var(--line)',
                  clipPath: 'polygon(0 0, calc(100% - 10px) 0, 100% 50%, calc(100% - 10px) 100%, 0 100%, 10px 50%)',
                  paddingLeft: i === 0 ? 12 : 18,
                  paddingRight: i === a.length - 1 ? 14 : 18,
                }}>{s}</div>
              );
            })}
          </div>
        </section>
        <section>
          <div className="caps" style={{ marginBottom: 12 }}>Tags & counters</div>
          <div style={{ display:'flex', gap: 8, flexWrap: 'wrap', alignItems:'center' }}>
            <span className="badge" style={{ background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--line-strong)' }}>SaaS</span>
            <span className="badge" style={{ background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--line-strong)' }}>Enterprise</span>
            <span className="badge" style={{ background: 'var(--surface)', color: 'var(--ink-2)', border: '1px solid var(--line-strong)' }}>NL · Utrecht</span>
            <span className="badge" style={{ background: 'var(--accent-soft)', color: 'var(--accent-deep)' }}><Pip size={5} color="var(--accent-deep)" />Hot lead</span>
            <span className="badge badge-neutral">+ 3</span>
            <span className="badge" style={{ background: 'var(--primary)', color: 'var(--on-primary)', height: 18, padding: '0 7px', fontSize: 10.5 }}>12</span>
          </div>
        </section>
        <section>
          <div className="caps" style={{ marginBottom: 12 }}>Inline indicators</div>
          <div style={{ display: 'flex', gap: 18, alignItems:'center', flexWrap:'wrap', fontSize: 13.5, color: 'var(--ink-2)' }}>
            <span style={{ display:'inline-flex', alignItems:'center', gap: 8 }}><Pip color="var(--success)" />Online</span>
            <span style={{ display:'inline-flex', alignItems:'center', gap: 8 }}><Pip color="var(--warning)" />Afwezig</span>
            <span style={{ display:'inline-flex', alignItems:'center', gap: 8 }}><Pip color="var(--ink-mute)" />Offline</span>
            <span style={{ display:'inline-flex', alignItems:'center', gap: 8 }}>
              <span style={{ display:'inline-flex', alignItems:'center', gap: 4, color: 'var(--success)' }}><VeldIcon name="arrowUp" size={12} strokeWidth={2.4} />+ 12%</span>
              <span style={{ color: 'var(--ink-3)' }}>versus vorige maand</span>
            </span>
          </div>
        </section>
      </div>
    </main>
  </div>
);

Object.assign(window, { ComponentsButtons, ComponentsForms, ComponentsBadges });
