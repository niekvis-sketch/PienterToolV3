// Foundations — Colors / Typography / Radii & Shadows / Iconography

const FoundationsIntro = () =>
<div className="veld-frame" style={{ background: 'var(--bg)' }}>
    <main style={{ padding: 56, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
      <div className="eyebrow">Design System · v0.1</div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 36, alignItems: 'flex-start' }}>
        <h1 style={{
        fontSize: 128, fontWeight: 600, letterSpacing: '-0.04em',
        margin: 0, color: 'var(--ink)', lineHeight: 0.95
      }}>
          Veld<span style={{ color: 'var(--accent)' }}>.</span>
        </h1>
        <button className="btn btn-primary btn-lg" style={{ paddingRight: 28 }}>
          Enter <VeldIcon name="arrowR" size={16} />
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
        <IntroSwatch label="Primary" value="#53935E" bg="var(--primary)" fg="rgba(255,255,255,0.92)" />
        <IntroSwatch label="Accent" value="#F6BDCA" bg="var(--accent)" fg="rgba(42,24,32,0.75)" />
        <IntroSwatch label="Highlight" value="#FFAB40" bg="var(--highlight)" fg="rgba(255,255,255,0.92)" />
        <IntroSwatch label="Base" value="#F9F7F2" bg="var(--bg)" fg="var(--ink-2)" bordered />
      </div>
    </main>
  </div>;


const IntroSwatch = ({ label, value, bg, fg, bordered }) =>
<div style={{
  height: 96, borderRadius: 'var(--r-3)', background: bg,
  border: bordered ? '1px solid var(--line-strong)' : '1px solid transparent',
  padding: '12px 14px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
  color: fg
}}>
    <span className="caps" style={{ color: fg, opacity: bordered ? 1 : 0.85 }}>{label}</span>
    <span className="mono" style={{ fontSize: 12.5, color: fg }}>{value}</span>
  </div>;


const FoundationsBrand = () =>
<div className="veld-frame">
    <main style={{ padding: 40, display: 'flex', flexDirection: 'column', gap: 32 }}>
      <div className="eyebrow">Design System · v0.1</div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 12 }}>
        <h1 style={{ fontSize: 96, fontWeight: 600, letterSpacing: '-0.04em', margin: 0, color: 'var(--primary)' }}>Veld</h1>
        <Pip size={18} />
        <span className="mono" style={{ color: 'var(--ink-3)', fontSize: 12 }}>/vɛlt/ — open ruimte</span>
      </div>
      <p style={{ fontSize: 18, lineHeight: 1.45, color: 'var(--ink-2)', maxWidth: 520, margin: 0 }}>
        Een rustig, zakelijk design system. Sage groen als hoofdkleur, zachte roze als decoratie, oranje als highlight — op warme crème basis.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginTop: 8 }}>
        <div style={{ height: 120, borderRadius: 'var(--r-3)', background: 'var(--primary)', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', inset: 12, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', color: 'var(--on-primary)' }}>
            <span className="caps" style={{ color: 'rgba(255,255,255,0.8)' }}>Primary</span>
            <span className="mono" style={{ fontSize: 13 }}>#53935E</span>
          </div>
        </div>
        <div style={{ height: 120, borderRadius: 'var(--r-3)', background: 'var(--accent)', position: 'relative', overflow: 'hidden', backgroundColor: "rgb(246, 189, 202)" }}>
          <div style={{ position: 'absolute', inset: 12, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', color: 'var(--on-accent)' }}>
            <span className="caps" style={{ color: 'rgba(42,24,32,0.65)' }}>Accent</span>
            <span className="mono" style={{ fontSize: 13 }}>#F6BDCA</span>
          </div>
        </div>
        <div style={{ height: 120, borderRadius: 'var(--r-3)', background: 'var(--highlight)', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', inset: 12, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', color: 'var(--on-highlight)' }}>
            <span className="caps" style={{ color: 'rgba(255,255,255,0.85)' }}>Highlight</span>
            <span className="mono" style={{ fontSize: 13 }}>#FFAB40</span>
          </div>
        </div>
        <div style={{ height: 120, borderRadius: 'var(--r-3)', background: 'var(--bg)', position: 'relative', overflow: 'hidden', border: '1px solid var(--line)' }}>
          <div style={{ position: 'absolute', inset: 12, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <span className="caps">Base</span>
            <span className="mono" style={{ fontSize: 13, color: 'var(--ink-2)' }}>#F9F7F2</span>
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 24, marginTop: 12, flexWrap: 'wrap' }}>
        {[
      ['Rust', 'rustige, leesbare interface'],
      ['Helder', 'duidelijke navigatie'],
      ['Subtiele randjes', 'kleine animaties, accentkleur, speelse iconen']].
      map(([k, v]) =>
      <div key={k} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <Pip />
            <div>
              <div style={{ fontWeight: 500, fontSize: 14 }}>{k}</div>
              <div style={{ fontSize: 13, color: 'var(--ink-3)' }}>{v}</div>
            </div>
          </div>
      )}
      </div>
    </main>
  </div>;


const FoundationsColors = () =>
<div className="veld-frame">
    <main>
      <ABHead eyebrow="Foundations" title="Kleurpalet" hint="oklch · semantic tokens" />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
        <section>
          <div className="caps" style={{ marginBottom: 12 }}>Primary · Sage</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
            <Swatch name="Primary" varName="--primary" value="#53935E" on="rgba(255,255,255,0.85)" />
            <Swatch name="Primary hover" varName="--primary-hover" value="#467F51" on="rgba(255,255,255,0.85)" />
            <Swatch name="Primary press" varName="--primary-press" value="#3B6E44" on="rgba(255,255,255,0.85)" />
            <Swatch name="Primary soft" varName="--primary-soft" value="#E5F0E7" />
            <Swatch name="Soft 2" varName="--primary-soft-2" value="#C9E0CE" />
          </div>
        </section>
        <section>
          <div className="caps" style={{ marginBottom: 12 }}>Accent · Rose</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
            <Swatch name="Accent" varName="--accent" value="#D9477A" on="#fff" />
            <Swatch name="Accent hover" varName="--accent-hover" value="#C53867" on="#fff" />
            <Swatch name="Accent press" varName="--accent-press" value="#AE2D58" on="#fff" />
            <Swatch name="Accent soft" varName="--accent-soft" value="#FBE7EF" />
            <Swatch name="Soft 2" varName="--accent-soft-2" value="#F4C7D8" />
          </div>
        </section>
        <section>
          <div className="caps" style={{ marginBottom: 12 }}>Neutrals · Warm cream</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12 }}>
            <Swatch name="Background" varName="--bg" value="#F4EFE3" size="sm" />
            <Swatch name="Elev" varName="--bg-elev" value="#FBF7EC" size="sm" />
            <Swatch name="Surface" varName="--surface" value="#FFFFFF" size="sm" />
            <Swatch name="Line" varName="--line" value="#E6DFCB" size="sm" />
            <Swatch name="Line strong" varName="--line-strong" value="#D4CAB1" size="sm" />
            <Swatch name="Ink" varName="--ink" value="#14241B" on="rgba(244,239,227,0.85)" size="sm" />
          </div>
        </section>
        <section>
          <div className="caps" style={{ marginBottom: 12 }}>Status</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
            <Swatch name="Success" varName="--success" value="#1F8A5B" on="#fff" size="sm" />
            <Swatch name="Warning" varName="--warning" value="#C77F3D" on="#fff" size="sm" />
            <Swatch name="Danger" varName="--danger" value="#B83A3A" on="#fff" size="sm" />
            <Swatch name="Info" varName="--info" value="#3D6EB8" on="#fff" size="sm" />
          </div>
        </section>
      </div>
    </main>
  </div>;


const FoundationsType = () => {
  const Row = ({ size, label, weight = 500, sample, mono, tracking = '-0.01em' }) =>
  <div style={{ display: 'grid', gridTemplateColumns: '140px 1fr 140px', alignItems: 'baseline', padding: '14px 0', borderBottom: '1px solid var(--line)' }}>
      <div>
        <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--ink)' }}>{label}</div>
        <div className="mono" style={{ fontSize: 11, color: 'var(--ink-3)' }}>{size}px / {weight}</div>
      </div>
      <div style={{ fontSize: size, fontWeight: weight, letterSpacing: tracking, fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)', color: 'var(--ink)', lineHeight: 1.15 }}>{sample}</div>
      <div className="mono" style={{ fontSize: 11, color: 'var(--ink-3)', textAlign: 'right' }}>{mono ? 'JetBrains Mono' : 'Poppins'}</div>
    </div>;

  return (
    <div className="veld-frame">
      <main>
        <ABHead eyebrow="Foundations" title="Typografie" hint="Poppins · JetBrains Mono" />
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <Row size={44} weight={600} label="Display" sample="Een rustige uitstraling" />
          <Row size={32} weight={600} label="Heading 1" sample="Klanten en deals" />
          <Row size={24} weight={600} label="Heading 2" sample="Recente activiteit" />
          <Row size={18} weight={500} label="Heading 3" sample="Pijplijn overzicht" />
          <Row size={14} weight={400} label="Body" sample="Veld is ontworpen voor lange, geconcentreerde werkdagen — rustig in kleurgebruik en helder in hiërarchie." tracking="0" />
          <Row size={12} weight={400} label="Small" sample="Bijgewerkt 4 minuten geleden" tracking="0" />
          <Row size={12.5} weight={500} label="Mono / Data" mono sample="€ 12.480,00 · NL · #B-203" tracking="0" />
        </div>
      </main>
    </div>);

};

const FoundationsRadiiShadows = () => {
  const items = [
  { n: 'r-1', val: '4px', r: 'var(--r-1)' },
  { n: 'r-2', val: '6px', r: 'var(--r-2)' },
  { n: 'r-3', val: '8px', r: 'var(--r-3)' },
  { n: 'r-4', val: '12px', r: 'var(--r-4)' },
  { n: 'pill', val: '999px', r: 'var(--r-pill)' }];

  const shadows = [
  { n: 'shadow-1', label: 'Hover lift' },
  { n: 'shadow-2', label: 'Card / dropdown' },
  { n: 'shadow-3', label: 'Modal / overlay' }];

  const spacing = [4, 8, 12, 16, 24, 32, 48];
  return (
    <div className="veld-frame">
      <main>
        <ABHead eyebrow="Foundations" title="Radii, schaduw & spacing" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32 }}>
          <section>
            <div className="caps" style={{ marginBottom: 12 }}>Radii</div>
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
              {items.map((i) =>
              <div key={i.n} style={{ textAlign: 'center' }}>
                  <div style={{ width: 72, height: 72, background: 'var(--primary-soft)', border: '1px solid var(--primary-soft-2)', borderRadius: i.r }} />
                  <div style={{ marginTop: 8, fontSize: 12, fontWeight: 500 }}>{i.n}</div>
                  <div className="mono" style={{ fontSize: 10.5, color: 'var(--ink-3)' }}>{i.val}</div>
                </div>
              )}
            </div>
            <hr className="divider-dotted" />
            <div className="caps" style={{ marginBottom: 12 }}>Schaduw</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
              {shadows.map((s) =>
              <div key={s.n} style={{ background: 'var(--surface)', height: 56, borderRadius: 'var(--r-3)', boxShadow: `var(--${s.n})`, border: '1px solid var(--line)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 16px' }}>
                  <span style={{ fontSize: 13, fontWeight: 500 }}>{s.label}</span>
                  <span className="mono" style={{ fontSize: 11, color: 'var(--ink-3)' }}>{s.n}</span>
                </div>
              )}
            </div>
          </section>
          <section>
            <div className="caps" style={{ marginBottom: 12 }}>Spacing (4px basis)</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {spacing.map((s) =>
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <span className="mono" style={{ width: 40, fontSize: 11, color: 'var(--ink-3)' }}>{s}px</span>
                  <div style={{ height: 8, width: s * 5, background: 'var(--accent)', borderRadius: 'var(--r-1)' }} />
                </div>
              )}
            </div>
            <hr className="divider-dotted" />
            <div className="caps" style={{ marginBottom: 12 }}>Motion</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 13, color: 'var(--ink-2)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Hover / tint</span><span className="mono" style={{ color: 'var(--ink-3)' }}>120ms ease</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Card lift / button</span><span className="mono" style={{ color: 'var(--ink-3)' }}>150ms ease</span></div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Modal / drawer</span><span className="mono" style={{ color: 'var(--ink-3)' }}>220ms cubic</span></div>
            </div>
          </section>
        </div>
      </main>
    </div>);

};

const FoundationsIcons = () => {
  const names = ['home', 'contacts', 'deals', 'pipeline', 'inbox', 'calendar', 'chart', 'settings', 'search', 'mail', 'phone', 'bell', 'user', 'filter', 'sort', 'star', 'flag', 'leaf', 'sparkle', 'plus', 'check', 'arrowR', 'edit', 'eye', 'trash', 'upload', 'dots', 'chevD'];
  return (
    <div className="veld-frame">
      <main>
        <ABHead eyebrow="Foundations" title="Iconografie" hint="1.6px stroke · 24px grid" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 12 }}>
          {names.map((n) =>
          <div key={n} style={{ aspectRatio: '1', background: 'var(--surface)', border: '1px solid var(--line)', borderRadius: 'var(--r-2)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, color: 'var(--ink)' }}>
              <VeldIcon name={n} size={22} />
              <span className="mono" style={{ fontSize: 10, color: 'var(--ink-3)' }}>{n}</span>
            </div>
          )}
        </div>
        <div style={{ marginTop: 24, padding: 14, background: 'var(--accent-soft)', borderRadius: 'var(--r-2)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <VeldIcon name="sparkle" size={18} accent style={{ color: 'var(--accent-press)' }} />
          <span style={{ fontSize: 13, color: 'var(--accent-press)' }}>
            Optionele <strong>accent-dot</strong> rechtsboven om actie of nieuwheid te markeren.
          </span>
        </div>
      </main>
    </div>);

};

Object.assign(window, { FoundationsIntro, FoundationsBrand, FoundationsColors, FoundationsType, FoundationsRadiiShadows, FoundationsIcons });