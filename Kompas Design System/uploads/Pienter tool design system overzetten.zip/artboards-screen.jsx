// Sample CRM dashboard — putting it all together

const ScreenDashboard = () => (
  <div className="veld-frame" style={{ background: 'var(--bg)' }}>
    <main style={{ padding: 0, display: 'grid', gridTemplateColumns: '232px 1fr', height: '100%' }}>
      {/* Sidebar (compact reuse) */}
      <aside style={{ background: 'var(--bg-elev)', borderRight: '1px solid var(--line)', padding: '20px 14px', display:'flex', flexDirection:'column', gap: 20 }}>
        <div style={{ display:'flex', alignItems:'center', gap: 10, padding: '4px 6px' }}>
          <div style={{ width: 28, height: 28, borderRadius: 'var(--r-2)', background: 'var(--primary)', display:'flex', alignItems:'center', justifyContent:'center', color: 'var(--on-primary)', fontWeight: 700, fontSize: 14 }}>V</div>
          <span style={{ fontWeight: 600 }}>Veld CRM</span>
          <Pip />
        </div>
        <div>
          <div className="caps" style={{ padding: '0 8px 8px' }}>Werkruimte</div>
          <div style={{ display:'flex', flexDirection:'column', gap: 2 }}>
            <div className="nav-item is-active"><VeldIcon name="home" size={17} />Overzicht</div>
            <div className="nav-item"><VeldIcon name="contacts" size={17} />Klanten<span className="mono" style={{ marginLeft:'auto', fontSize: 11, color: 'var(--ink-3)' }}>248</span></div>
            <div className="nav-item"><VeldIcon name="deals" size={17} />Deals<span className="badge badge-accent" style={{ marginLeft:'auto', height: 18, padding:'0 7px', fontSize: 10.5 }}>3</span></div>
            <div className="nav-item"><VeldIcon name="pipeline" size={17} />Pijplijn</div>
            <div className="nav-item"><VeldIcon name="inbox" size={17} />Inbox</div>
            <div className="nav-item"><VeldIcon name="calendar" size={17} />Agenda</div>
          </div>
        </div>
        <div>
          <div className="caps" style={{ padding: '0 8px 8px' }}>Inzicht</div>
          <div style={{ display:'flex', flexDirection:'column', gap: 2 }}>
            <div className="nav-item"><VeldIcon name="chart" size={17} />Rapportages</div>
            <div className="nav-item"><VeldIcon name="settings" size={17} />Instellingen</div>
          </div>
        </div>
        <div style={{ marginTop:'auto', padding: 12, background:'var(--surface)', border:'1px solid var(--line)', borderRadius:'var(--r-3)' }}>
          <div style={{ display:'flex', gap: 10, alignItems:'center' }}>
            <span className="avatar">SK</span>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Sanne Krijger</div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)' }}>Account manager</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Workspace */}
      <section style={{ display:'flex', flexDirection:'column', minWidth: 0 }}>
        <header style={{ height: 60, borderBottom: '1px solid var(--line)', display:'flex', alignItems:'center', padding:'0 24px', gap: 16, flexShrink: 0 }}>
          <div style={{ display:'flex', alignItems:'center', gap: 8, fontSize: 13, color: 'var(--ink-3)' }}>
            <span>Werkruimte</span><VeldIcon name="chevR" size={13} /><span style={{ color: 'var(--ink)', fontWeight: 500 }}>Overzicht</span>
          </div>
          <div style={{ marginLeft: 'auto', display:'flex', gap: 10, alignItems:'center' }}>
            <div style={{ position:'relative' }}>
              <VeldIcon name="search" size={15} style={{ position:'absolute', left:10, top:'50%', transform:'translateY(-50%)', color:'var(--ink-3)' }} />
              <input className="input" placeholder="Zoek…" style={{ width: 200, height: 34, paddingLeft: 32, fontSize: 13 }} />
            </div>
            <button className="btn btn-secondary" style={{ width: 34, padding: 0, height: 34 }}>
              <span style={{ position:'relative' }}><VeldIcon name="bell" size={15} /><Pip size={6} style={{ position:'absolute', top: -2, right: -2 }} /></span>
            </button>
            <button className="btn btn-primary btn-sm"><VeldIcon name="plus" size={14} />Nieuw</button>
          </div>
        </header>

        <div style={{ flex: 1, padding: 24, overflow: 'auto' }}>
          {/* Greeting + KPIs */}
          <div style={{ display:'flex', alignItems:'flex-end', justifyContent:'space-between', marginBottom: 18 }}>
            <div>
              <div className="caps">Maandag 11 mei</div>
              <h1 style={{ fontSize: 28, fontWeight: 600, letterSpacing:'-0.02em', margin: '6px 0 0' }}>Goedemorgen, Sanne<Pip color="var(--accent)" size={10} style={{ marginLeft: 8 }} /></h1>
            </div>
            <div style={{ display:'flex', gap: 8 }}>
              <button className="btn btn-secondary btn-sm">Deze week<VeldIcon name="chevD" size={13} /></button>
              <button className="btn btn-secondary btn-sm"><VeldIcon name="upload" size={13} />Export</button>
            </div>
          </div>

          <div style={{ display:'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 18 }}>
            {[
              ['Pijplijn waarde', '€ 184.500', '+ 8%', 'success'],
              ['Actieve deals', '24', '+ 3', 'success'],
              ['Nieuwe leads', '12', '+ 4', 'accent'],
              ['Win rate', '34%', '− 2%', 'danger'],
            ].map(([k, v, d, t], i) => (
              <div key={k} className="card" style={{ padding: 16 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                  <div className="caps">{k}</div>
                  <span style={{ fontSize: 11, color: t === 'success' ? 'var(--success)' : t === 'accent' ? 'var(--accent-press)' : 'var(--danger)', fontWeight: 500 }}>{d}</span>
                </div>
                <div style={{ fontSize: 24, fontWeight: 600, letterSpacing: '-0.02em', marginTop: 8 }}>{v}</div>
                <svg viewBox="0 0 100 24" style={{ width: '100%', height: 24, marginTop: 8 }}>
                  <path d={i === 3 ? "M0 8 L20 10 L40 12 L60 14 L80 18 L100 20" : "M0 20 L20 16 L40 18 L60 12 L80 10 L100 6"} fill="none" stroke={t === 'success' ? 'var(--success)' : t === 'accent' ? 'var(--accent)' : 'var(--danger)'} strokeWidth="1.5" />
                </svg>
              </div>
            ))}
          </div>

          {/* Two-column: pipeline + activity */}
          <div style={{ display:'grid', gridTemplateColumns: '1.6fr 1fr', gap: 16 }}>
            <div className="card">
              <div className="card-header">
                <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
                  <span style={{ fontWeight: 600 }}>Pijplijn</span>
                  <span className="badge badge-neutral">24 deals</span>
                </div>
                <button className="btn btn-ghost btn-sm">Detail<VeldIcon name="arrowR" size={13} /></button>
              </div>
              <div style={{ padding: 16, display:'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10 }}>
                {[
                  ['Lead', 8, 'var(--ink-mute)', 0],
                  ['Demo', 6, 'var(--primary-soft-2)', 28400],
                  ['Offerte', 5, 'var(--primary)', 62100],
                  ['Onderhandeling', 3, 'var(--accent)', 54800],
                  ['Gewonnen', 2, 'var(--success)', 39200],
                ].map(([l, n, c, eur]) => (
                  <div key={l} style={{ display:'flex', flexDirection:'column', gap: 6 }}>
                    <div style={{ height: 4, background: c, borderRadius: 2 }} />
                    <div style={{ fontSize: 12, color: 'var(--ink-3)' }}>{l}</div>
                    <div style={{ fontSize: 20, fontWeight: 600, letterSpacing:'-0.02em' }}>{n}</div>
                    <div className="mono" style={{ fontSize: 11, color: 'var(--ink-3)' }}>{eur ? `€ ${(eur/1000).toFixed(1)}k` : '—'}</div>
                  </div>
                ))}
              </div>
              <div style={{ padding: '0 16px 16px' }}>
                <div style={{ display:'flex', flexDirection:'column', gap: 8 }}>
                  {[
                    { naam: 'De Korenmaat', fase: 'Onderhandeling', faseColor: 'warning', waarde: '€ 24.500', persoon: 'MV', dag: 'over 2 dagen', hot: true },
                    { naam: 'Boombond NL', fase: 'Offerte',       faseColor: 'accent',  waarde: '€ 18.200', persoon: 'HT', dag: 'donderdag' },
                    { naam: 'KaalKeurig',  fase: 'Demo',          faseColor: 'primary', waarde: '€ 8.400',  persoon: 'PB', dag: 'volgende week' },
                  ].map((r, i) => (
                    <div key={i} style={{ display:'flex', alignItems:'center', gap: 12, padding: '10px 12px', background: 'var(--bg-elev)', borderRadius: 'var(--r-2)', border: '1px solid var(--line)' }}>
                      <span className="avatar" style={{ width: 28, height: 28, fontSize: 11 }}>{r.persoon}</span>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 13.5, fontWeight: 500, display:'flex', gap: 6, alignItems:'center' }}>
                          {r.naam}{r.hot && <Pip color="var(--accent)" size={6} />}
                        </div>
                        <div className="mono" style={{ fontSize: 11, color: 'var(--ink-3)' }}>{r.dag}</div>
                      </div>
                      <span className={`badge badge-${r.faseColor}`}><span className="dot" />{r.fase}</span>
                      <span className="mono" style={{ fontSize: 12.5, fontWeight: 500, width: 76, textAlign:'right' }}>{r.waarde}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Activity column */}
            <div style={{ display:'flex', flexDirection:'column', gap: 12 }}>
              <div className="card">
                <div className="card-header">
                  <span style={{ fontWeight: 600 }}>Vandaag</span>
                  <span className="mono" style={{ fontSize: 11, color: 'var(--ink-3)' }}>3 acties</span>
                </div>
                <div style={{ padding: '4px 16px 12px' }}>
                  {[
                    { t: '09:30', what: 'Bel Mira van Dijk', sub: 'Voor offertegesprek', icon: 'phone', tone: 'accent' },
                    { t: '11:00', what: 'Demo KaalKeurig', sub: 'Met Pjotr & Iris', icon: 'calendar', tone: 'primary' },
                    { t: '15:00', what: 'Stuur follow-up Boombond', sub: 'Volg-op offerte', icon: 'mail', tone: 'neutral' },
                  ].map((r, i) => (
                    <div key={i} style={{ display:'flex', gap: 12, alignItems: 'flex-start', padding: '10px 0', borderBottom: i < 2 ? '1px dashed var(--line)' : 'none' }}>
                      <span className="mono" style={{ width: 38, fontSize: 11, color: 'var(--ink-3)', paddingTop: 4 }}>{r.t}</span>
                      <span style={{
                        width: 28, height: 28, borderRadius: 'var(--r-2)',
                        background: r.tone === 'accent' ? 'var(--accent-soft)' : r.tone === 'primary' ? 'var(--primary-soft)' : 'var(--bg-elev)',
                        color: r.tone === 'accent' ? 'var(--accent-press)' : r.tone === 'primary' ? 'var(--primary)' : 'var(--ink-2)',
                        display:'flex', alignItems:'center', justifyContent:'center', flexShrink: 0,
                      }}><VeldIcon name={r.icon} size={14} /></span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, fontWeight: 500 }}>{r.what}</div>
                        <div style={{ fontSize: 11.5, color: 'var(--ink-3)' }}>{r.sub}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card" style={{ background: 'var(--primary)', color: 'var(--on-primary)', border: 'none' }}>
                <div style={{ padding: 16 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                    <VeldIcon name="sparkle" size={16} accent />
                    <span className="caps" style={{ color: 'rgba(244,239,227,0.7)' }}>Vraag Veld AI</span>
                  </div>
                  <div style={{ fontSize: 15, lineHeight: 1.4 }}>3 deals zijn 5+ dagen stil. Wil je een follow-up draftje voor ze opstellen?</div>
                  <div style={{ display:'flex', gap: 8, marginTop: 12 }}>
                    <button className="btn btn-accent btn-sm">Stel voor</button>
                    <button className="btn btn-ghost btn-sm" style={{ color: 'rgba(244,239,227,0.8)' }}>Later</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  </div>
);

Object.assign(window, { ScreenDashboard });
